/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package assignment1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author sandrandlovu
 */
public class ProductTest {
    
    public ProductTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getProdCode method, of class Product.
     */
    @Test
    public void testGetProdCode() {
        System.out.println("getProdCode");
        Product instance = new Product();
        String expResult = "";
        String result = instance.getProdCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setProdCode method, of class Product.
     */
    @Test
    public void testSetProdCode() {
        System.out.println("setProdCode");
        String prodCode = "";
        Product instance = new Product();
        instance.setProdCode(prodCode);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getProdName method, of class Product.
     */
    @Test
    public void testGetProdName() {
        System.out.println("getProdName");
        Product instance = new Product();
        String expResult = "";
        String result = instance.getProdName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setProdName method, of class Product.
     */
    @Test
    public void testSetProdName() {
        System.out.println("setProdName");
        String prodName = "";
        Product instance = new Product();
        instance.setProdName(prodName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCategory method, of class Product.
     */
    @Test
    public void testGetCategory() {
        System.out.println("getCategory");
        Product instance = new Product();
        String expResult = "";
        String result = instance.getCategory();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCategory method, of class Product.
     */
    @Test
    public void testSetCategory() {
        System.out.println("setCategory");
        String category = "";
        Product instance = new Product();
        instance.setCategory(category);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getWarranty method, of class Product.
     */
    @Test
    public void testGetWarranty() {
        System.out.println("getWarranty");
        Product instance = new Product();
        String expResult = "";
        String result = instance.getWarranty();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setWarranty method, of class Product.
     */
    @Test
    public void testSetWarranty() {
        System.out.println("setWarranty");
        String warranty = "";
        Product instance = new Product();
        instance.setWarranty(warranty);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPrice method, of class Product.
     */
    @Test
    public void testGetPrice() {
        System.out.println("getPrice");
        Product instance = new Product();
        double expResult = 0.0;
        double result = instance.getPrice();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPrice method, of class Product.
     */
    @Test
    public void testSetPrice() {
        System.out.println("setPrice");
        double price = 0.0;
        Product instance = new Product();
        instance.setPrice(price);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLevel method, of class Product.
     */
    @Test
    public void testGetLevel() {
        System.out.println("getLevel");
        Product instance = new Product();
        int expResult = 0;
        int result = instance.getLevel();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLevel method, of class Product.
     */
    @Test
    public void testSetLevel() {
        System.out.println("setLevel");
        int level = 0;
        Product instance = new Product();
        instance.setLevel(level);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSupplier method, of class Product.
     */
    @Test
    public void testGetSupplier() {
        System.out.println("getSupplier");
        Product instance = new Product();
        String expResult = "";
        String result = instance.getSupplier();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSupplier method, of class Product.
     */
    @Test
    public void testSetSupplier() {
        System.out.println("setSupplier");
        String supplier = "";
        Product instance = new Product();
        instance.setSupplier(supplier);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Product.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Product instance = new Product();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStockLevel method, of class Product.
     */
    @Test
    public void testSetStockLevel() {
        System.out.println("setStockLevel");
        int nextInt = 0;
        Product instance = new Product();
        instance.setStockLevel(nextInt);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
