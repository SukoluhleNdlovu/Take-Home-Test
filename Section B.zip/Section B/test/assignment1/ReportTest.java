/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package assignment1;

import java.util.Scanner;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author sandrandlovu
 */
public class ReportTest {
    
    public ReportTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of addProduct method, of class Report.
     */
    @Test
    public void testAddProduct() {
        System.out.println("addProduct");
        Scanner in = null;
        Report instance = new Report();
        instance.addProduct(in);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchProduct method, of class Report.
     */
    @Test
    public void testSearchProduct() {
        System.out.println("searchProduct");
        Scanner in = null;
        Report instance = new Report();
        Product expResult = null;
        Product result = instance.searchProduct(in);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of update method, of class Report.
     */
    @Test
    public void testUpdate() {
        System.out.println("update");
        Scanner in = null;
        String prodCode = "";
        Report instance = new Report();
        instance.update(in, prodCode);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of report method, of class Report.
     */
    @Test
    public void testReport() {
        System.out.println("report");
        Report instance = new Report();
        instance.report();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of delete method, of class Report.
     */
    @Test
    public void testDelete() {
        System.out.println("delete");
        Scanner in = null;
        Report instance = new Report();
        instance.delete(in);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
