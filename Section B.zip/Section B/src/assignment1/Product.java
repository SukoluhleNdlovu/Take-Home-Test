/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;
/**
 *
 * @author sandrandlovu
 */
public class Product {
//variables
private String prodCode;
private String prodName;
private String category;
private String warranty;
private double price;
private int level;
private String supplier;

//constructor details
public Product() {
this.warranty = "2 years";// default warranty is 2 years
}

public String getProdCode() {
return prodCode;
}

public void setProdCode(String prodCode) {
this.prodCode = prodCode;
}

public String getProdName() {
return prodName;
}

public void setProdName(String prodName) {
this.prodName = prodName;
}

public String getCategory() {
return category;
}

public void setCategory(String category) {
this.category = category;
}

public String getWarranty() {
return warranty;
}

public void setWarranty(String warranty) {
if(warranty.equals("1"))
this.warranty = "6 months";
}

public double getPrice() {
return price;
}

public void setPrice(double price) {
this.price = price;
}

public int getLevel() {
return level;
}

public void setLevel(int level) {
this.level = level;
}

public String getSupplier() {
return supplier;
}

public void setSupplier(String supplier) {
this.supplier = supplier;
}

@Override
public String toString() {
return "PRODUCT CODE >> \t" + prodCode + "\nPRODUCT NAME >> \t" + prodName + "\nPRODUCT CATEGORY >> \t" + category + "\nPRODUCT WARRANTY >> \t"
+ warranty + "\nPRODUCT PRICE >> \t" + price + "\nPRODUCT LEVEL >> \t" + level + "\nPRODUCT SUPPLIER >> \t" + supplier ;
}
    void setStockLevel(int nextInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }  
}
