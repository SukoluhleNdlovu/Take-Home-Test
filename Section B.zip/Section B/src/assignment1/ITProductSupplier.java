/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignment1;
import java.util.*;
/**
 *
 * @author sukoluhlendlovu
 */
public class ITProductSupplier {
static Report newReport;
    /**
     * @param args the command line arguments
     * Extreme IT Products is a local supplier that specialises in the sales of the latest Information 
     * Technology hardware devices. The business has recently opened an outlet in the town you reside 
     * and has hired the software development house you work for to design a Java application to manage their products. 
     * Your line manager has requested you to develop the application with the following 
     */
    public static void main(String[] args) {
      // TODO code application logic here
       // scanner object for reading user input
      Scanner input = new Scanner(System.in);
      // object for ReportData
      newReport = new Report();
      //loop for welcome message
    while (true) {
       showWelcomeMessage();
       String choice = input.nextLine();
      if (!choice.equals("1")) {
    break;
  } 
     //loop for menu
    while (true) {
      showMenu();
      choice = input.nextLine();
      if(choice.equals("6"))
        break;
     switch(choice){
          case "1" -> newReport.addProduct(input);
          case "2" -> {
           Product item = newReport.searchProduct(input);
    if( item!= null)
        System.out.println(item);
    else
        System.out.println("The product can't be located. Please try again.");
        }
       case "3" -> newReport.update(input, choice);
       case "4" -> newReport.delete(input);
       case "5" -> newReport.report();
       default -> System.out.println("Invalid entry...");
        }
    }
  }
}
//method to display welcome message
private static void showWelcomeMessage() {
  System.out.println("""
                     BRIGHT FUTURE TECHNOLOGIES APPLICATION 
                     ************************************** 
                     Enter (1) to launch menu or any other key to exit""");  
}
//method to display menu
private static void showMenu() {
  System.out.println("""
                     Please select one of the menu item: 
                     (1). Capture a new product 
                     (2). Search for a product 
                     (3). Update a product 
                     (4). Delete a product 
                     (5). Print report 
                     (6). Exit application""");
}
}

    
          
        
        
        
  
        
        
        
        




    
    
    

    
    
    
    
    
