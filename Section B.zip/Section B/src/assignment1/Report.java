/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author sandrandlovu
 */
public class Report {
// list of products
private final ArrayList<Product> products ;
// array for categories
private final String[] categories;

public Report() {
this.categories = new String[] {"Desktop Computer", "Laptop", "Tablet", "Printer", "Gaming console"};
products = new ArrayList<>();
}
//method to add a new product to list
void addProduct(Scanner in) {
System.out.println("CAPTURE A NEW PRODUCT");
System.out.println("**********************");
Product newProduct = new Product();
System.out.print("Enter product code: ");
newProduct.setProdCode(in.nextLine());
System.out.print("Enter product name: ");
newProduct.setProdName(in.nextLine());
System.out.println("Enter product category: ");
int choice;
// loop for category selection
while (true) {
for (int i = 0; i < categories.length; i++) {
System.out.println(categories[i] + " - " + (i + 1));
}
System.out.print("Product category: ");
try{
choice = Integer.parseInt(in.nextLine());
if(choice>0 && choice<=categories.length)
break;
}
catch(NumberFormatException e){
System.out.println("Incorrect selection.");
}
}
newProduct.setCategory(categories[choice-1]);
setWarranty(newProduct, in);
setPrice(newProduct, in);
setStockLevel(newProduct, in);
System.out.print("Enter supplier for "+newProduct.getProdName()+": ");
newProduct.setSupplier(in.nextLine());
products.add(newProduct);
System.out.println("Product has been saved successfully \n");
}
//method to set stock level of a product
private void setStockLevel(Product newProduct, Scanner in) throws NumberFormatException {
System.out.print("Enter stock level for "+newProduct.getProdName()+": ");
newProduct.setLevel(Integer.parseInt(in.nextLine()));
}
//method to set price of a product
private void setPrice(Product newProduct, Scanner in) throws NumberFormatException {
System.out.print("Enter price for "+newProduct.getProdName()+": ");
newProduct.setPrice(Double.parseDouble(in.nextLine()));
}
//method to set warranty of a product
private void setWarranty(Product newProduct, Scanner in) {
System.out.print("Indicate product warranty. Enter (1) for 6 months or any other keys for 2 years: ");
newProduct.setWarranty(in.nextLine());
}
// method to search a product in the products list
Product searchProduct(Scanner in) {
System.out.println("Enter product code: ");
String prodCode = in.nextLine();
System.out.println("""
                   *************************** 
                    PRODUCT SEARCH RESULT 
                   ***************************""");
for(int i=0; i<products.size(); i++){
if(products.get(i).getProdCode().equals(prodCode)){
return products.get(i);
}
}
return null;
}
// method to update details of product
public void update(Scanner in, String prodCode) {
Product p = searchProduct(in);
for(int i = 0;i<products.size();i++){
if(p!=null){
System.out.print("Update the warranty? (Yes/No): ");
String choice = in.nextLine();
if(choice.equalsIgnoreCase("YES")){
    System.out.print("Enter the new warranty:");
    products.get(i).setWarranty(in.nextLine());
    System.out.println("The warranty has been successfully updated.");
}
System.out.print("Update the price? (Yes/No): ");
choice = in.nextLine();
if(choice.equalsIgnoreCase("YES")){
    System.out.print("Enter the new price:");
    products.get(i).setPrice(in.nextInt());
    System.out.println("The price of product code has been successfully updated.");
}
System.out.print("Update the stock price? (Yes/No): ");
choice = in.nextLine();
if(choice.equalsIgnoreCase("YES")){
    System.out.print("Enter the updated stock level:");
    products.get(i).setPrice(in.nextInt());
    System.out.println("The stock level of product code has been successfully updated.");
}  
}
else{
    System.out.println("The product canot be located. Invalid product.");
}
}
}

// method to display report
public void report() {
double total = 0;
System.out.println("PRODUCT REPORT");
System.out.println("=========================================");
for(int i=0; i<products.size(); i++){
   System.out.println("PRODUCT "+(i+1));
   System.out.println("--------------------------------------------------");
   System.out.println(products.get(i));
   total += products.get(i).getPrice();
   System.out.println("--------------------------------------------------");
}
System.out.println("TOTAL PRODUCT COUNT: "+products.size());
System.out.println("TOTAL PRODUCT VALUE: R "+total);
System.out.printf("TOTAL PRODUCT VALUE: R %.2f",total/products.size());
}
// method to delete a product
public void delete(Scanner in) {
Product p = searchProduct(in);
if(p!=null){
System.out.print("Do you want to delete "+p.getProdCode()+"? (y)yes (n)no: ");
String choice = in.nextLine();
if(choice.equalsIgnoreCase("y")){
products.remove(p);
System.out.println(p.getProdCode() +" deleted.");
}
}
else{
System.out.println("The product canot be located. Invalid product.");
}
}

}
